/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pro.Model;

/**
 *
 * @author Akshay
 */
public class doctor {
    
 protected int userId;
 private String password;
 private String specialisetion;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSpecialisetion() {
        return specialisetion;
    }

    public void setSpecialisetion(String specialisetion) {
        this.specialisetion = specialisetion;
    }
 
    
}
